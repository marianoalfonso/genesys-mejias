<?php

    echo "se produjo un error (ver para analizar tipo de errores en base a variables de sesion)";

?>